<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\Property;

class MtcApiController extends Controller
{
    public function getData(){
        $response = Http::get('https://trial.craig.mtcserver15.com/api/properties');
        $data = $response->json();
        //$total_record       = $data['total'];
        //$record_per_page    = 2;
        //$number_of_page     = ceil ($data['total'] / $record_per_page);
        //$counter = 1;
        return response()->json($data['total']);
    }

    public function setData(Request $request){
        $response_per_page = Http::get('https://trial.craig.mtcserver15.com/api/properties?page[number]='.$request->input('page_no').'&page[size]='.$request->input('record_per_page') .'&api_key=3NLTTNlXsi6rBWl7nYGluOdkl2htFHug');
        $data = $response_per_page->json();
        for($i=0; $i<$request->input('record_per_page'); $i++){//Fetch per page record
            $property = Property::updateOrCreate(
                [
                    'uuid' => $data['data'][$i]['uuid']
                ],
                [
                'county' => $data['data'][$i]['county'],
                'country' => $data['data'][$i]['country'],
                'town' => $data['data'][$i]['town'],
                'description' => $data['data'][$i]['description'],
                'image_url' => $data['data'][$i]['image_full'],
                'address' => $data['data'][$i]['address'],
                'thumbnail_url' => $data['data'][$i]['image_thumbnail'],
                'latitude' => $data['data'][$i]['latitude'],
                'longitude' => $data['data'][$i]['longitude'],
                'num_bedrooms' => $data['data'][$i]['num_bedrooms'],
                'num_bathrooms' => $data['data'][$i]['num_bathrooms'],
                'price' => $data['data'][$i]['price'],
                'property_type_id' => $data['data'][$i]['property_type_id'],
                'sale_or_rent' => $data['data'][$i]['type'],
                'uuid' => $data['data'][$i]['uuid']
                ]);
        }
        return response()->json($i-1);
    }
}
