<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Property extends Model
{
    use HasFactory;
    protected $fillable = ['county', 'country', 'town', 'postcode', 'description', 'full_details_url', 
                            'address', 'image_url', 'thumbnail_url', 'latitude', 'longitude', 
                            'num_bathrooms', 'num_bedrooms', 'price', 'property_type_id', 'sale_or_rent', 'uuid'];
}
