<template>
    <div>
    <button class="btn btn-danger" @click="getProperty()">Get Data</button>
    <h1>Total Record : {{properties}}</h1>
    </div>
</template>
<script>
export default {
    data() {
        return {
            properties: 0,
            record_per_page: 100,
            number_of_page: 0
        }
    },
    methods: {
        getProperty() {
            this.axios
            .get(`http://localhost:8000/api/get-property`)
            .then(response => {
                this.number_of_page     = Math.ceil (response.data / this.record_per_page);
                    this.saveProperty(1);
                    this.number_of_page = this.number_of_page-1;
            });
        },
        saveProperty(page_no) {
            this.axios
            .post(`http://localhost:8000/api/save-property`, {
                    page_no: page_no,
                    record_per_page: this.record_per_page
                })
            .then(response => {
                this.properties = response.data+this.properties;
                if(this.number_of_page != 0) {
                    this.number_of_page = this.number_of_page - 1;
                    this.saveProperty(this.number_of_page);
                }
            });
        }
    }
}
</script>