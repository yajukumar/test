<template>
<div>
<h3 class="text-center">Edit Property</h3>
<div class="row">
<div class="col-md-6">
<form @submit.prevent="updateProperty">
    <div class="form-group">
    <label>County</label>
    <input type="text" class="form-control" v-model="property.county">
    </div>
    <div class="form-group">
    <label>Country</label>
    <input type="text" class="form-control" v-model="property.country">
    </div>
    <div class="form-group">
    <label>Town</label>
    <input type="text" class="form-control" v-model="property.town">
    </div>
    <div class="form-group">
    <label>Postcode</label>
    <input type="text" class="form-control" v-model="property.postcode">
    </div>
    <div class="form-group">
    <label>Description</label>
    <textarea class="form-control" v-model="property.description"></textarea>
    </div>
    <div class="form-group">
    <label>Address</label>
    <input type="text" class="form-control" v-model="property.address">
    </div>
    <div class="form-group">
    <label>Image Uploadl</label>
    <input type="text" class="form-control" v-model="property.image_url">
    </div>
    <div class="form-group">
    <label>Number of bedrooms</label>
        <select v-model="property.num_bedrooms">
        <option disabled value="">Please select one</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        </select>
    </div>
    <div class="form-group">
    <label>Number of bathrooms</label>
        <select v-model="property.num_bathrooms">
        <option disabled value="">Please select one</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        </select>
      </div>
    <div class="form-group">
    <label>Price</label>
    <input type="text" class="form-control" v-model="property.price">
    </div>
    <div class="form-group">
    <label>Property Type</label>
        <select v-model="property.property_type_id">
        <option disabled value="">Please select one</option>
        <option v-for="property_type in property_types" v-bind:value="property_type.id">
        {{ property_type.title }}
        </option>
        </select>
    </div>
    <div class="form-group">
    <label>For Sale / For Rent: </label>
    <input type="radio" id="yes" value="sales" v-model="property.sale_or_rent">
    <label for="yes">Yes</label>
    <input type="radio" id="no" value="rent" v-model="property.sale_or_rent">
    <label for="no">No</label>
    </div>
<button type="submit" class="btn btn-primary">Update</button>
</form>
</div>
</div>
</div>
</template>
<script>
export default {
    data() {
        return {
        property: {},
        property_types: {}
        }
    },
    mounted() {
        this.getPropertyType()
    },
    created() {
        this.axios
        .get(`http://localhost:8000/api/property/${this.$route.params.id}`)
        .then((res) => {
        this.property = res.data;
        });
       
    },
    methods: {
        updateProperty() {
            this.axios
            .patch(`http://localhost:8000/api/property/${this.$route.params.id}`, this.property)
            .then((res) => {
            this.$router.push({ name: 'home' });
            });
        },
        getPropertyType() {
            this.axios
            .get('http://localhost:8000/api/property_type/')
            .then(responsess => {
             this.property_types = responsess.data;
            });
        }
    }
}
</script>