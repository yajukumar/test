<template>
    <div>
        <h2 class="text-center">Property List</h2>
            <table class="table">
                <thead>
                    <tr>
                    <th>ID</th>
                    <th>County</th>
                    <th>Country</th>
                    <!-- <th>Actions</th> -->
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="property in properties" :key="property.id">
                        <td>{{ property.id }}</td>
                        <td>{{ property.county }}</td>
                        <td>{{ property.country }}</td>
                        <td>
                        <div class="btn-group" role="group">
                        <router-link :to="{name: 'edit', params: { id: property.id }}" class="btn btn-success">Edit</router-link>
                        <button class="btn btn-danger" @click="deleteProperty(property.id)">Delete</button>
                        </div>
                        </td>
                    </tr>
                </tbody>
            </table>
    </div>
</template>
<script>
export default {
data() {
return {
properties: []
}
},
created() {
this.axios
    .get('http://localhost:8000/api/property/')
    .then(response => {
    this.properties = response.data;
    });
},
methods: {
deleteProperty(id) {
this.axios
.delete(`http://localhost:8000/api/property/${id}`)
.then(response => {
let i = this.properties.map(data => data.id).indexOf(id);
this.properties.splice(i, 1)
});
}
}
}
</script>