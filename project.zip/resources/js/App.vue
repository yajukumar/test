<template>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="collapse navbar-collapse">
                <div class="navbar-nav">
                    <router-link to="/" class="nav-item nav-link">Property List</router-link>
                    <router-link to="/create" class="nav-item nav-link">Create Property</router-link>
                    <router-link to="/mtc" class="nav-item nav-link">Fetch data from Mtc api</router-link>
                </div>
            </div>
        </nav>
        <router-view> </router-view>
    </div>
</template>
<script>
export default {}
</script>