<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePropertiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('properties', function (Blueprint $table) {
            $table->id();
            $table->text('county')->nullable();
            $table->text('country')->nullable();
            $table->text('town')->nullable();
            $table->text('postcode')->nullable();
            $table->text('description')->nullable();
            $table->text('full_details_url')->nullable();
            $table->text('address')->nullable();
            $table->text('image_url')->nullable();
            $table->text('thumbnail_url')->nullable();
            $table->text('latitude')->nullable();
            $table->text('longitude')->nullable();
            $table->integer('num_bedrooms')->nullable();
            $table->integer('num_bathrooms')->nullable();
            $table->bigInteger('price')->nullable();
            $table->integer('property_type_id')->nullable();
            $table->text('sale_or_rent')->nullable();
            $table->text('uuid')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('properties');
    }
}
